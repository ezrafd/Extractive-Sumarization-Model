https://github.com/kavgan/ROUGE-2.0
java -jar rouge2-1.2.2.jar